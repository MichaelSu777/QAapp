howCode's simple Question and Answer site
=========================================

This is the source code for howCode's simple question and answer site built using Python and the Django web framework.

You can watch the video that accompanies this source code here: https://youtu.be/hR2PJ46orF8
